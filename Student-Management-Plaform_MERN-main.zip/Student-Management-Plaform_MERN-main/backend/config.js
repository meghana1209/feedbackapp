// config.js

module.exports = {
    mongoURI:"mongodb+srv://kwahome:AllanWahome@cluster0.hwtv1fk.mongodb.net/LMS-security",
  };  